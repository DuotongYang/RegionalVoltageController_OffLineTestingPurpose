﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SynchrophasorAnalytics.DataConditioning.Snr
{
    public enum SnrMeasurementType
    {
        Magnitude,

        Angle
    }
}
